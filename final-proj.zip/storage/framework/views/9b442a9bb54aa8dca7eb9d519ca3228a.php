<?php
    use Carbon\Carbon;
?>



<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="title-content">
            <h1>Jejak Aktifitas</h1>
        </div>
    </div>
    <div class="main-content">
        <div class="card-container">
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('log.show', ['log' => $log->id])); ?>" class="card-log">
                    <div class="title"><?php echo e($log->title); ?></div>
                    <div class="date"><?php echo e(Carbon::parse($log->created_at)->diffForHumans()); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('log.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\laragon\www\final-proj\resources\views/log/index.blade.php ENDPATH**/ ?>