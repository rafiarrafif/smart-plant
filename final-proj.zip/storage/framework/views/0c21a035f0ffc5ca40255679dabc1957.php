

<?php $__env->startSection('content'); ?>
    <button onclick="backPage()" class="back-container">
        <i data-feather="arrow-left" style="stroke: #b0a1fe"></i>
    </button>
    <div class="main-container">
        <div class="header-content">
            <div class="left-header">
                <div class="image-logo">
                    <img src="<?php echo e(asset('img/logo_large.png')); ?>" alt="sutarno-tech">
                </div>
            </div>
            <div class="right-header">
                <div class="title">
                    <h1>Siapakah Kami 🤫</h1>
                </div>
                <div class="subtitle">
                    <p>Terima kasih kepada semua Kontributor atas kontribusinya di project ini</p>
                </div>
            </div>
        </div>
        <div class="main-content">
            <div class="card-container">
                <div class="left-panel">
                    <a class="card-profile">
                        <div class="left-side">
                            <div class="profile-container">
                                <img src="<?php echo e(asset('img/profile-faisal.jpg')); ?>" alt="faisal-ridho-zulhilmi">
                            </div>
                        </div>
                        <div class="right-side">
                            <div class="name">
                                <p>Faisal Ridha Zulhilmi</p>
                            </div>
                            <div class="contrib">
                                <p>Hardware Engineer, Electrical Engineer, Hardware Designer, Product Designer, Wiring</p>
                            </div>
                        </div>
                    </a>
                    <a class="card-profile">
                        <div class="left-side">
                            <div class="profile-container">
                                <img src="<?php echo e(asset('img/profile-helmi.jpg')); ?>" alt="faisal-ridho-zulhilmi">
                            </div>
                        </div>
                        <div class="right-side">
                            <div class="name">
                                <p>Helmi Arrafif Kanahaya</p>
                            </div>
                            <div class="contrib">
                                <p>Full Stack Web Developer, Database Administrator, UI/UX Designer</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="right-panel">
                    <a class="card-profile">
                        <div class="left-side">
                            <div class="profile-container">
                                <img src="<?php echo e(asset('img/profile-anggito.jpg')); ?>" alt="faisal-ridho-zulhilmi">
                            </div>
                        </div>
                        <div class="right-side">
                            <div class="name">
                                <p>Anggito Abimanyu</p>
                            </div>
                            <div class="contrib">
                                <p>Finance Manager, Project Management, Guideline Designer</p>
                            </div>
                        </div>
                    </a>
                    <a class="card-profile">
                        <div class="left-side">
                            <div class="profile-container">
                                <img src="<?php echo e(asset('img/profile-syauqi.jpg')); ?>" alt="faisal-ridho-zulhilmi">
                            </div>
                        </div>
                        <div class="right-side">
                            <div class="name">
                                <p>Syauqi Dzul Rahman</p>
                            </div>
                            <div class="contrib">
                                <p>Product Designer, Guideline Desinger</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function backPage() {
            window.history.back();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('settings.layouts.follow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\laragon\www\final-proj\resources\views/settings/follow.blade.php ENDPATH**/ ?>