<?php
    use Carbon\carbon;
?>

<?php $__currentLoopData = $history->showerHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('shower.history.show', ['shower' => $data->id])); ?>" class="card-history">
        <div class="top">
            <div class="user-action-shower">
                <?php echo e(ucfirst($data->activatedBy->name ?? 'SYSTEM')); ?>

            </div>
            <div class="time">
                <?php echo e(Carbon::parse($data->created_at)->diffForHumans()); ?>

            </div>
        </div>
        <div class="bottom">
            <?php if($data->is_active == true): ?>
                <div class="shower-title">
                    Penyiraman masih berlangsung
                </div>
            <?php else: ?>
                <div class="shower-title">
                    Penyiraman selama <?php echo e($data->shower_diff); ?>

                </div>
            <?php endif; ?>
        </div>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Development\laragon\www\final-proj\resources\views/plants/partials/showerHistory.blade.php ENDPATH**/ ?>