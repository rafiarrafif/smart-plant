
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="icon-content">
            <img src="<?php echo e(asset('img/logo_large.png')); ?>">
        </div>
        <div class="header-content">
            <h1>Sistem Dibekukan</h1>
            <p>Sistem dibekukan oleh admin. Semua layanan yang berkaitan dengan aplikasi ini dihentikan dan semua akses
                ditutup</p>
        </div>
        <div class="action-btn">
            <a href="<?php echo e(route('home')); ?>">Segarkan</a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                <a href="<?php echo e(route('settings.suspend')); ?>">Buka Akses</a>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frezee.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\laragon\www\final-proj\resources\views/frezee/index.blade.php ENDPATH**/ ?>