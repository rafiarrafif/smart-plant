<?php
    use Carbon\Carbon;
?>



<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="fixed-content">
            <div class="back-btn" onclick="backPage()">
                <i data-feather="chevron-left" style="stroke: #b0a1fe"></i>
            </div>
            <div class="title-fixed">
                <span>Detail Jejak</span>
            </div>
        </div>
        <div class="main-show-content">
            <div class="title"><?php echo e($loging->title); ?></div>
            <div class="date">
                <?php echo e(Carbon::parse($loging->created_at)->isoFormat('D MMMM YYYY')); ?>&nbsp;&nbsp;&nbsp;<?php echo e(Carbon::parse($loging->created_at)->isoFormat('HH:mm:ss')); ?>

            </div>
            <hr class="separator">
            <div class="description"><?php echo e($loging->description); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function backPage() {
            window.history.back();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('log.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\laragon\www\final-proj\resources\views/log/show.blade.php ENDPATH**/ ?>