<?php
    use Carbon\Carbon;
?>




<?php $__env->startSection('content'); ?>
    <button onclick="backPage()" class="back-container">
        <i data-feather="arrow-left" style="stroke: #b0a1fe"></i>
    </button>
    <div class="main-container">
        <div class="left-container">
            <div class="profile-picture">
                <div class="image-container">
                    <img src="<?php echo e($userData->avatar); ?>" alt="profile-picture">
                </div>
            </div>
        </div>
        <div class="right-container">
            <div class="tagline">
                <h3>Data Pengguna</h3>
            </div>
            <div class="info-container">
                <div class="info-card">
                    <div class="label">
                        <span>Nama</span>
                    </div>
                    <div class="value">
                        <span><?php echo e($userData->name); ?></span>
                    </div>
                </div>
                <div class="info-card">
                    <div class="label">
                        <span>Email</span>
                    </div>
                    <div class="value">
                        <span><?php echo e($userData->email); ?></span>
                    </div>
                </div>
                <div class="info-card">
                    <div class="label">
                        <span>Login Via</span>
                    </div>
                    <div class="value">
                        <span><?php echo e($userData->vendor); ?></span>
                    </div>
                </div>
                <div class="info-card">
                    <div class="label">
                        <span>Bergabung Pada</span>
                    </div>
                    <div class="value">
                        <span><?php echo e($userData->created_at->isoFormat('D MMMM YYYY')); ?></span>
                    </div>
                </div>
            </div>
            <div class="edit-container">
                <div class="edit-content">
                    <div class="left-content">
                        <div class="icon">
                            <i data-feather="alert-triangle" style="stroke: #b0a1fe; width: 22px"></i>
                        </div>
                    </div>
                    <div class="right-content">
                        <div class="header">
                            <h3>Tidak bisa mengedit data</h3>
                        </div>
                        <div class="content">
                            <p>Kamu login menggunakan authentikasi pihak ketiga (<?php echo e($userData->vendor); ?> OAuth). Tenang,
                                kamu
                                masih
                                bisa merubah data kamu dengan cara melakukanya di Pusat Akun <?php echo e($userData->vendor); ?> dan
                                lakukan
                                login ulang pada
                                aplikasi ini</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function backPage() {
            window.history.back();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('settings.layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\laragon\www\final-proj\resources\views/settings/account.blade.php ENDPATH**/ ?>