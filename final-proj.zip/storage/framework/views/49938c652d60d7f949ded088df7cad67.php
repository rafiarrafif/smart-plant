<?php
    use Carbon\Carbon;
?>



<?php $__env->startSection('content'); ?>
    <div class="fixed-header">
        <div class="back-btn" onclick="backToPlant()">
            <i data-feather="chevron-left" style="stroke: #b0a1fe"></i>
        </div>
        <div class="title-plant">
            <span>Penyiraman <?php echo e($plant); ?></span>
        </div>
        <div class="del-btn" onclick="">
            <i data-feather="sliders" style="stroke: #b0a1fe"></i>
        </div>
    </div>
    <div class="main-content">
        <div class="loader-container">
            <div class="loader"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            setTimeout(() => {
                getData();
            }, 200);
        });

        function backToPlant() {
            window.history.back();
        }

        function getData() {
            $.ajax({
                url: "<?php echo e(route('api.shower.history.show', ['shower' => $history->id])); ?>",
                type: 'POST',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(data) {
                    $(".main-content").empty().append(data);
                },
                error: function(data) {
                    console.log(data);
                }
            })
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plants.layouts.showerHistory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\laragon\www\final-proj\resources\views/plants/showerHistory.blade.php ENDPATH**/ ?>