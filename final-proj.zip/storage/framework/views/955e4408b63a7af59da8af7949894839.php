<div class="bg-nav"></div>
<div class="navbar">
    <a href="<?php echo e(route('home')); ?>" class="navbar-a">
        <i data-feather="home"
            style="stroke: <?php echo e(Request::is('/') || (Request::is('plant/*') && !Request::is('plant/*/edit')) ? '#b0a1fe' : '#848384'); ?>; width: 22px"></i>
        <span
            class="<?php echo e(Request::is('/') || (Request::is('plant/*') && !Request::is('plant/*/edit')) ? 'active' : ''); ?>">Home</span>
    </a>
    <a href="<?php echo e(route('log')); ?>" class="navbar-a">
        <i data-feather="file-text" style="stroke: <?php echo e(Request::is('log*') ? '#b0a1fe' : '#848384'); ?>; width: 22px"></i>
        <span class="<?php echo e(Request::is('log*') ? 'active' : ''); ?>">Logs</span>
    </a>
    <a href="<?php echo e(route('settings.index')); ?>" class="navbar-a">
        <i data-feather="settings"
            style="stroke: <?php echo e(Request::is('plant/*/edit') || Request::is('settings*') ? '#b0a1fe' : '#848384'); ?>; width: 22px"></i>
        <span class="<?php echo e(Request::is('plant/*/edit') || Request::is('settings*') ? 'active' : ''); ?>">Settings</span>
    </a>
</div>
<?php /**PATH D:\Development\laragon\www\final-proj\resources\views/partials/navbar.blade.php ENDPATH**/ ?>