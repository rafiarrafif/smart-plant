<link rel="icon" href="<?php echo e(asset('img/logo.png')); ?>">
<?php /**PATH D:\Development\laragon\www\final-proj\resources\views/meta/main.blade.php ENDPATH**/ ?>