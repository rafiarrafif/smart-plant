<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('meta.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Hubungkan terlebih dahulu</title>

    <?php echo $__env->make('lib.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/plant.pairing.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/main.css')); ?>">
</head>

<body>
    <nav>
        <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script>
        feather.replace();
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\Development\laragon\www\final-proj\resources\views/plants/layouts/pairing.blade.php ENDPATH**/ ?>