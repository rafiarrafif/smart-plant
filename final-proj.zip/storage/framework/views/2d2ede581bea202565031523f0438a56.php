

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="fixed-header">
            <div class="back-btn" onclick="RedirectPage('<?php echo e(route('home')); ?>')">
                <i data-feather="chevron-left" style="stroke: #b0a1fe"></i>
            </div>
            <div class="title-plant">
                <span>Pairing <?php echo e($plant->name); ?></span>
            </div>
            <div class="del-btn" onclick="RedirectPage('<?php echo e(route('plant.edit', ['plant' => $plant->slug])); ?>')">
                <i data-feather="sliders" style="stroke: #b0a1fe; opacity: 0; pointer-events: none;"></i>
            </div>
        </div>
        <div class="card-token">
            <div class="header-token">
                <h1>Pairing Token</h1>
                <p>Sebelum menggunakan ini harap sambungkan ESP dengan id "<?php echo e($plant->id); ?>" dan dengan Token berikut
                    ini pada Endpoint API:</p>
            </div>
            <div class="main-highlight-token">
                <div class="main">
                    <span><?php echo e($plant->keystream); ?></span>
                    <button onclick="copyToClipboard('<?php echo e($plant->keystream); ?>')">
                        <i data-feather="clipboard" style="width: 18px; stroke: #cacaca"></i>
                    </button>
                </div>
            </div>
            <div class="action-token">
                <a href="<?php echo e(route('plant.show', ['plant' => $plant->slug])); ?>">Muat Ulang</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function RedirectPage(url) {
            window.location.href = url;
        }

        function copyToClipboard(data) {
            navigator.clipboard.writeText(data);

            console.log("Copied the text: " + data);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plants.layouts.pairing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\laragon\www\final-proj\resources\views/plants/pairing.blade.php ENDPATH**/ ?>