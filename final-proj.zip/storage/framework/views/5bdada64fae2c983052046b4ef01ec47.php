<?php
    use Carbon\Carbon;
?>

<div class="main-description">
    <?php if($history->is_actived_by_system == false && $history->is_deactived_by_system == false): ?>
        <p>Pada tanggal <?php echo e(Carbon::parse($history->shower_on)->isoFormat('D MMMM YYYY')); ?> disaat pukul
            <?php echo e(Carbon::parse($history->shower_on)->isoFormat('HH:mm:ss')); ?> WIB, pengguna dengan nama
            <span><?php echo e(ucfirst($history->activatedBy->name)); ?></span> melakukan penyiraman pada tanaman
            <?php echo e($history->plant->name); ?>. Penyiraman berlangsung selama <?php echo e($history->shower_diff); ?>, lalu dimatikan pada
            pukul <?php echo e(Carbon::parse($history->shower_off)->isoFormat('HH:mm:ss')); ?> WIB oleh pengguna dengan nama
            <span><?php echo e(ucfirst($history->deactivatedBy->name)); ?></span>. Berikut perbedaan data statistik tanaman
            <?php echo e($history->plant->name); ?> sebelum dan sesudah penyiraman:
        </p>
    <?php elseif($history->is_actived_by_system == true && $history->is_deactived_by_system == true): ?>
        <p>Pada tanggal <?php echo e(Carbon::parse($history->shower_on)->isoFormat('D MMMM YYYY')); ?> disaat pukul
            <?php echo e(Carbon::parse($history->shower_on)->isoFormat('HH:mm:ss')); ?> WIB,
            <span style="color: #b1a0fd">SISTEM</span> melakukan penyiraman pada
            tanaman
            <?php echo e($history->plant->name); ?>. Penyiraman berlangsung selama <?php echo e($history->shower_diff); ?>, lalu dimatikan
            pada
            pukul <?php echo e(Carbon::parse($history->shower_off)->isoFormat('HH:mm:ss')); ?> WIB oleh
            <span style="color: #b1a0fd">SISTEM</span>. Berikut perbedaan data
            statistik tanaman
            <?php echo e($history->plant->name); ?> sebelum dan sesudah penyiraman:
        </p>
    <?php elseif($history->is_actived_by_system == false && $history->is_deactived_by_system == true): ?>
        <p>Pada tanggal <?php echo e(Carbon::parse($history->shower_on)->isoFormat('D MMMM YYYY')); ?> disaat pukul
            <?php echo e(Carbon::parse($history->shower_on)->isoFormat('HH:mm:ss')); ?> WIB, pengguna dengan nama
            <span><?php echo e(ucfirst($history->activatedBy->name)); ?></span> melakukan penyiraman pada tanaman
            <?php echo e($history->plant->name); ?>. Penyiraman berlangsung selama <?php echo e($history->shower_diff); ?>, lalu dimatikan
            pada
            pukul <?php echo e(Carbon::parse($history->shower_off)->isoFormat('HH:mm:ss')); ?> WIB oleh <span
                style="color: #b1a0fd">SISTEM</span>.
            Berikut perbedaan data statistik tanaman
            <?php echo e($history->plant->name); ?> sebelum dan sesudah penyiraman:
        </p>
    <?php elseif($history->is_actived_by_system == true && $history->is_deactived_by_system == false): ?>
        <p>Pada tanggal <?php echo e(Carbon::parse($history->shower_on)->isoFormat('D MMMM YYYY')); ?> disaat pukul
            <?php echo e(Carbon::parse($history->shower_on)->isoFormat('HH:mm:ss')); ?> WIB, pengguna dengan nama
            <span style="color: #b1a0fd">SISTEM</span> melakukan penyiraman pada tanaman
            <?php echo e($history->plant->name); ?>. Penyiraman berlangsung selama <?php echo e($history->shower_diff); ?>, lalu dimatikan
            pada
            pukul <?php echo e(Carbon::parse($history->shower_off)->isoFormat('HH:mm:ss')); ?> WIB oleh pengguna dengan nama
            <span><?php echo e(ucfirst($history->deactivatedBy->name)); ?></span>. Berikut perbedaan data statistik tanaman
            <?php echo e($history->plant->name); ?> sebelum dan sesudah penyiraman:
        </p>
    <?php endif; ?>
    <div class="table-compare">
        <table>
            <thead>
                <th>Parameter</th>
                <th>Sebelum</th>
                <th>Sesudah</th>
            </thead>
            <tbody>
                <tr>
                    <td>Kelembapan Udara</td>
                    <td><?php echo e($history->air_before); ?>%</td>
                    <td><?php echo e($history->air_after); ?>%</td>
                </tr>
                <tr>
                    <td>Kelembapan Tanah (%)</td>
                    <td><?php echo e($history->soil_before_percent); ?>%</td>
                    <td><?php echo e($history->soil_after_percent); ?>%</td>
                </tr>
                <tr>
                    <td>Kelembapan Tanah</td>
                    <td><?php echo e($history->soil_before); ?></td>
                    <td><?php echo e($history->soil_after); ?></td>
                </tr>
                <tr>
                    <td>Suhu Ruangan (°C)</td>
                    <td><?php echo e($history->temp_before); ?></td>
                    <td><?php echo e($history->temp_after); ?></td>
                </tr>
                <tr>
                    <td>Suhu Ruangan (°F)</td>
                    <td><?php echo e($history->fahrenheit_before); ?></td>
                    <td><?php echo e($history->fahrenheit_after); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    <p style="margin-top: 22px">Detail singkat tentang penyiraman ini:</p>
    <div class="table-compare table-description">
        <table>
            <tbody>
                <tr>
                    <td>Nama Tanaman</td>
                    <td><?php echo e($history->plant->name); ?></td>
                </tr>
                <tr>
                    <td>Dinyalakan oleh</td>
                    <td><?php echo e($history->is_actived_by_system == true ? 'SISTEM' : $history->activatedBy->name); ?></td>
                </tr>
                <tr>
                    <td>Dimatikan oleh</td>
                    <td><?php echo e($history->is_deactived_by_system == true ? 'SISTEM' : $history->deactivatedBy->name); ?></td>
                </tr>
                <tr>
                    <td>Durasi Penyiraman</td>
                    <td><?php echo e($history->shower_diff); ?></td>
                </tr>
                <tr>
                    <td>Dinyalakan pada</td>
                    <td><?php echo e(Carbon::parse($history->shower_on)->isoFormat('D MMMM YYYY HH:mm:ss')); ?></td>
                </tr>
                <tr>
                    <td>Dimatikan pada</td>
                    <td><?php echo e(Carbon::parse($history->shower_on)->isoFormat('D MMMM YYYY HH:mm:ss')); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\Development\laragon\www\final-proj\resources\views/plants/partials/showShowerHistory.blade.php ENDPATH**/ ?>